import java.util.*;

class HelloWorld {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take input for the number of items
        System.out.print("Enter the number of items: ");
        int n = scanner.nextInt();

        int[] val = new int[n];
        int[] wt = new int[n];

        // Take input for values
        System.out.println("Enter the values of the items: ");
        for (int i = 0; i < n; i++) {
            val[i] = scanner.nextInt();
        }

        // Take input for weights
        System.out.println("Enter the weights of the items: ");
        for (int i = 0; i < n; i++) {
            wt[i] = scanner.nextInt();
        }

        // Take input for maximum capacity
        System.out.print("Enter the maximum capacity of the knapsack: ");
        int W = scanner.nextInt();

        double[][] ratio = new double[val.length][2];

        // Calculate the value-to-weight ratio
        for (int i = 0; i < val.length; i++) {
            ratio[i][0] = i;
            ratio[i][1] = val[i] / (double) wt[i];
        }

        // Sort items based on value-to-weight ratio in descending order
        Arrays.sort(ratio, Comparator.comparingDouble(o -> -o[1]));

        int capacity = W;
        int finalVal = 0;

        // Calculate maximum value for the knapsack
        for (int i = 0; i < ratio.length; i++) {
            int idx = (int) ratio[i][0];
            if (capacity >= wt[idx]) {
                finalVal += val[idx];
                capacity -= wt[idx];
            } else {
                finalVal += (ratio[i][1] * capacity);
                capacity = 0;
                break;
            }
        }

        System.out.println("Maximum value in the knapsack = " + finalVal);

        scanner.close();
    }
}
