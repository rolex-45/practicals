package OOPS_PG.Recursion;
import java.util.*;
public class fibonacchi {
    public static int fib(int n){
        if(n==0 || n==1){
            return n;
        }
        return fib(n-1)+fib(n-2);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter fibonacchi number:");
        int n=sc.nextInt();
        System.out.println(fib(n));
        
    }
    
}
int a = 0, b = 1, c, i; 

 if( n == 0) 

 return a; 

 for (i = 2; i <= n; i++) 

 { 

 c = a + b; 

 a = b; 

 b = c; 

 } 

 return b; 

 #include <iostream>
using namespace std;

// Recursive function to calculate Fibonacci number
int fibonacci_recursive(int n) {
    if (n <= 1) {
        return n;
    }
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
}

int main() {
    int n = 5;  // Number of terms

    // Non-recursive approach (iterative)
    cout << "Non-recursive (iterative) Fibonacci sequence: ";
    int num1 = 0, num2 = 1;
    for (int i = 0; i < n; i++) {
        cout << num1 << " ";
        int num3 = num1 + num2;
        num2 = num1;
        num1 = num3;
    }
    cout << endl;

    // Recursive approach
    cout << "Recursive Fibonacci sequence: ";
    for (int i = 0; i < n; i++) {
        cout << fibonacci_recursive(i) << " ";
    }
    cout << endl;

    return 0;
}
